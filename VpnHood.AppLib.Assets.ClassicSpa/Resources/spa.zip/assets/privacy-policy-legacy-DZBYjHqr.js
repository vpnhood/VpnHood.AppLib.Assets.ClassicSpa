System.register(["./index-legacy-DpkBbPeJ.js"],(function(e,t){"use strict";return{setters:[t=>{t.I,e("default",t.I)}],execute:function(){}}}));
