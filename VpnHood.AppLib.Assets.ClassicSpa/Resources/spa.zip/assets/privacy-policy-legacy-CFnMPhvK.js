System.register(["./index-legacy-B6MINZ5p.js"],function(e,t){"use strict";return{setters:[t=>{t.O,e("default",t.O)}],execute:function(){}}});
