System.register(["./index-legacy-6Vqn4td9.js"],(function(e,t){"use strict";return{setters:[t=>{t.B,e("default",t.B)}],execute:function(){}}}));
