System.register(["./index-legacy-B1kQmPjR.js"],(function(e,t){"use strict";return{setters:[t=>{t.J,e("default",t.J)}],execute:function(){}}}));
