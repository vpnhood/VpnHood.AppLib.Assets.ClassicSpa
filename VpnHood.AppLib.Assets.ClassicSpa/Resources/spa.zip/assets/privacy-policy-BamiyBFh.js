import{O as f}from"./index-BGw5gwsP.js";export{f as default};
