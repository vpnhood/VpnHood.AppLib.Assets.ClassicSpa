System.register(["./index-legacy-DiUzNrSZ.js"],function(e,t){"use strict";return{setters:[t=>{t.N,e("default",t.N)}],execute:function(){}}});
