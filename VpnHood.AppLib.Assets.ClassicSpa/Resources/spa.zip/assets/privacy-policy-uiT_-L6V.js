import{I as f}from"./index-DaTcDCvI.js";export{f as default};
