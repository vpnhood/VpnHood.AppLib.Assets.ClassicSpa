System.register(["./index-legacy-CIk_LSMS.js"],(function(e,t){"use strict";return{setters:[t=>{t.y,e("default",t.y)}],execute:function(){}}}));
