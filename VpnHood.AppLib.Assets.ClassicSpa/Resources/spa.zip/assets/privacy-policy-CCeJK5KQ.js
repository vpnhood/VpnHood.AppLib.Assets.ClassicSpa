import{y as f}from"./index-DzqqhWzC.js";export{f as default};
