System.register(["./index-legacy-Bpq9UMrz.js"],(function(e,t){"use strict";return{setters:[t=>{t._,e("default",t._)}],execute:function(){}}}));
