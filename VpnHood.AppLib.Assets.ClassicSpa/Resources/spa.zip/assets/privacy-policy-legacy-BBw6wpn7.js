System.register(["./index-legacy-Bst8Kzw3.js"],(function(e,t){"use strict";return{setters:[t=>{t.G,e("default",t.G)}],execute:function(){}}}));
