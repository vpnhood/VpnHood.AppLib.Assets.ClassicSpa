System.register(["./index-legacy-CW7Poc2n.js"],(function(e,t){"use strict";return{setters:[t=>{t.y,e("default",t.y)}],execute:function(){}}}));
