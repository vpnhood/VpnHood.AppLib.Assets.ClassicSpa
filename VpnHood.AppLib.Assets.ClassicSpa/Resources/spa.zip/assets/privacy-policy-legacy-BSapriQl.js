System.register(["./index-legacy-D2iHswZk.js"],(function(e,t){"use strict";return{setters:[t=>{t.J,e("default",t.J)}],execute:function(){}}}));
