import{P as f}from"./index-CuFpPaWF.js";export{f as default};
