System.register(["./index-legacy-B5MvTUnG.js"],function(e,t){"use strict";return{setters:[t=>{t._,e("default",t._)}],execute:function(){}}});
