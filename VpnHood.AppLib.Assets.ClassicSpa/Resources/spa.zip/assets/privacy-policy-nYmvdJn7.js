import{P as f}from"./index-BGL9eRMC.js";export{f as default};
