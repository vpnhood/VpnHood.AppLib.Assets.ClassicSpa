System.register(["./index-legacy-DdFgl4_i.js"],function(e,t){"use strict";return{setters:[t=>{t.P,e("default",t.P)}],execute:function(){}}});
