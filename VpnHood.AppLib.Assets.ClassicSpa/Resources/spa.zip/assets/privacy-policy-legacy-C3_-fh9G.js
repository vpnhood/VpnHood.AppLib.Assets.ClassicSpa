System.register(["./index-legacy-ThGKsa_g.js"],(function(e,t){"use strict";return{setters:[t=>{t.J,e("default",t.J)}],execute:function(){}}}));
