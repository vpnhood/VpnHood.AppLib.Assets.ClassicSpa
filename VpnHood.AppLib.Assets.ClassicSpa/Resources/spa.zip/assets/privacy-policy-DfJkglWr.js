import{P as f}from"./index-bCdGZ454.js";export{f as default};
