System.register(["./index-legacy-wt8q7FN0.js"],function(e,t){"use strict";return{setters:[t=>{t.N,e("default",t.N)}],execute:function(){}}});
