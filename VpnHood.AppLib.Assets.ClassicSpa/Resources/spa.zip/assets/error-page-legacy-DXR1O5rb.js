System.register(["./index-legacy-CIk_LSMS.js"],(function(e,t){"use strict";return{setters:[t=>{t._,e("default",t._)}],execute:function(){}}}));
