import{y as f}from"./index-BFZDT0UE.js";export{f as default};
