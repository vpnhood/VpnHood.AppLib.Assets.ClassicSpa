System.register(["./index-legacy-BMMif2Cq.js"],(function(e,t){"use strict";return{setters:[t=>{t.z,e("default",t.z)}],execute:function(){}}}));
