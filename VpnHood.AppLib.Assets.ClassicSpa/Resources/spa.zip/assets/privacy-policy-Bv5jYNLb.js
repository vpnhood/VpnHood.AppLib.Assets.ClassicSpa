import{y as f}from"./index-B2fmxeJN.js";export{f as default};
