System.register(["./index-legacy-CXgX6qzx.js"],(function(e,t){"use strict";return{setters:[t=>{t.N,e("default",t.N)}],execute:function(){}}}));
