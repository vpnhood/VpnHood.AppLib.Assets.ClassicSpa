import{P as f}from"./index-BcJ3hARe.js";export{f as default};
