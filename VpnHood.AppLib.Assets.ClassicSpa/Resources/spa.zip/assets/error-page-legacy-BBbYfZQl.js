System.register(["./index-legacy-D-Or9qfj.js"],(function(e,t){"use strict";return{setters:[t=>{t._,e("default",t._)}],execute:function(){}}}));
