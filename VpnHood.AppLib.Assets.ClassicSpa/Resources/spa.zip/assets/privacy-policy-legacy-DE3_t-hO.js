System.register(["./index-legacy-CYviLMEZ.js"],function(e,t){"use strict";return{setters:[t=>{t.P,e("default",t.P)}],execute:function(){}}});
