import{P as f}from"./index-C2hXeARP.js";export{f as default};
