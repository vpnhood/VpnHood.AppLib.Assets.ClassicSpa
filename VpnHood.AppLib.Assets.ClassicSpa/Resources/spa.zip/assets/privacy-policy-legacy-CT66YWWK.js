System.register(["./index-legacy-DZWHNrqM.js"],(function(e,t){"use strict";return{setters:[t=>{t.y,e("default",t.y)}],execute:function(){}}}));
