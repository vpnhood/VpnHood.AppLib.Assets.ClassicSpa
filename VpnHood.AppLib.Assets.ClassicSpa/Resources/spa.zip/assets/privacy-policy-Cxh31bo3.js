import{P as f}from"./index-CUfqW0tz.js";export{f as default};
