import{N as f}from"./index-CofX1ugH.js";export{f as default};
