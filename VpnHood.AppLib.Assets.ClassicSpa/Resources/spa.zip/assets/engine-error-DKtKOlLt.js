import{_ as f}from"./index-BUgspe8q.js";export{f as default};
