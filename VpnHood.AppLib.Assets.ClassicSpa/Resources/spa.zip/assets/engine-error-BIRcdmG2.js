import{_ as f}from"./index-B--gHeLv.js";export{f as default};
