import{y as f}from"./index-CN1cTXFr.js";export{f as default};
