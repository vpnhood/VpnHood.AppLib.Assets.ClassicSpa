System.register(["./index-legacy-BWhEEgpy.js"],(function(e,t){"use strict";return{setters:[t=>{t.I,e("default",t.I)}],execute:function(){}}}));
