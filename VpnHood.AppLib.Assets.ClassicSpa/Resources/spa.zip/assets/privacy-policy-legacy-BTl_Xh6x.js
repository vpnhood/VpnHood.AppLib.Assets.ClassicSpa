System.register(["./index-legacy-Bpq9UMrz.js"],(function(e,t){"use strict";return{setters:[t=>{t.z,e("default",t.z)}],execute:function(){}}}));
