import{I as f}from"./index-C67Lrmpg.js";export{f as default};
