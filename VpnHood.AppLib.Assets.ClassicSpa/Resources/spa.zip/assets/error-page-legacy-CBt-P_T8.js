System.register(["./index-legacy-CReo_ezQ.js"],(function(e,t){"use strict";return{setters:[t=>{t._,e("default",t._)}],execute:function(){}}}));
