import{N as f}from"./index-BKYyFuUf.js";export{f as default};
