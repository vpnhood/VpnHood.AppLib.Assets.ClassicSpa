System.register(["./index-legacy-WkSxbusR.js"],function(e,t){"use strict";return{setters:[t=>{t.N,e("default",t.N)}],execute:function(){}}});
