System.register(["./index-legacy-xpDWlFeZ.js"],(function(e,t){"use strict";return{setters:[t=>{t.H,e("default",t.H)}],execute:function(){}}}));
