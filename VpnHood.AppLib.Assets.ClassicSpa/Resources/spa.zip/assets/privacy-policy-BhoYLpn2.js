import{J as f}from"./index-B0lrphAy.js";export{f as default};
