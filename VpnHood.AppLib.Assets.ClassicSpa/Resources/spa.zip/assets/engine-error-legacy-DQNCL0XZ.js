System.register(["./index-legacy-DdFgl4_i.js"],function(e,t){"use strict";return{setters:[t=>{t._,e("default",t._)}],execute:function(){}}});
