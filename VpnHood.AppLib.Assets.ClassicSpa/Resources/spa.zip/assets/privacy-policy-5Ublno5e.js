import{J as f}from"./index-BcwknCLq.js";export{f as default};
