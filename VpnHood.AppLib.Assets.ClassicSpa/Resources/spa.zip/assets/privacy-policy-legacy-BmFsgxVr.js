System.register(["./index-legacy-BU0uJmDZ.js"],(function(e,t){"use strict";return{setters:[t=>{t.z,e("default",t.z)}],execute:function(){}}}));
