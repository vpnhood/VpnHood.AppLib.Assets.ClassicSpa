System.register(["./index-legacy-pG66VGOp.js"],(function(e,t){"use strict";return{setters:[t=>{t.z,e("default",t.z)}],execute:function(){}}}));
