System.register(["./index-legacy-CReo_ezQ.js"],(function(e,t){"use strict";return{setters:[t=>{t.I,e("default",t.I)}],execute:function(){}}}));
