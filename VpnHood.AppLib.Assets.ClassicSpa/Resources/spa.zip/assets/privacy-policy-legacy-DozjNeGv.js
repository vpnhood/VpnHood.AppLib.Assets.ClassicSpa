System.register(["./index-legacy-B1RqAzWj.js"],function(e,t){"use strict";return{setters:[t=>{t.P,e("default",t.P)}],execute:function(){}}});
