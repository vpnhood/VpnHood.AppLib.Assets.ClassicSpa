System.register(["./index-legacy-CBfmT7_M.js"],(function(e,t){"use strict";return{setters:[t=>{t.J,e("default",t.J)}],execute:function(){}}}));
