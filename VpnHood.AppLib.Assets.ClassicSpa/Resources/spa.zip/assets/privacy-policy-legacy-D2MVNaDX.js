System.register(["./index-legacy-D3sLxJwC.js"],(function(e,t){"use strict";return{setters:[t=>{t.J,e("default",t.J)}],execute:function(){}}}));
