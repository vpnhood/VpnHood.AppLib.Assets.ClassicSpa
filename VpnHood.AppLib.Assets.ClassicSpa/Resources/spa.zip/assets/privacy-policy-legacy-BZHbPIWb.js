System.register(["./index-legacy-cE8SAqbJ.js"],(function(e,t){"use strict";return{setters:[t=>{t.z,e("default",t.z)}],execute:function(){}}}));
