System.register(["./index-legacy-BNRLGq3W.js"],(function(e,t){"use strict";return{setters:[t=>{t.z,e("default",t.z)}],execute:function(){}}}));
