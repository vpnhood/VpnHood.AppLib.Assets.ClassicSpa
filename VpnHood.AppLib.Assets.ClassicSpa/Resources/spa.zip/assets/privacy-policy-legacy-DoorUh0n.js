System.register(["./index-legacy-BXoAQMN6.js"],(function(e,t){"use strict";return{setters:[t=>{t.B,e("default",t.B)}],execute:function(){}}}));
