System.register(["./index-legacy-PVHR1R_O.js"],function(e,t){"use strict";return{setters:[t=>{t.N,e("default",t.N)}],execute:function(){}}});
