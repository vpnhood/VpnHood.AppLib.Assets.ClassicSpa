System.register(["./index-legacy-Bxs1PVpR.js"],function(e,t){"use strict";return{setters:[t=>{t.O,e("default",t.O)}],execute:function(){}}});
